﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
namespace TheSubsystemOfTestingInformationSecuritySpecialistsGavrilov
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (tabControl1.SelectedIndex < tabControl1.Items.Count - 1)
                tabControl1.SelectedIndex++;
        }
        private int mistake = 0;
        private int sum = 0;
        private void buttonfull_Click(object sender, RoutedEventArgs e)
        {
            button1.IsEnabled = false;
            buttonfull.IsEnabled = false;
            foreach (TabItem tabItem in tabControl1.Items)
            {
                tabItem.IsEnabled = true;
            }
            sum = -1;
            mistake = 0;
            List<RadioButton> answerButtons = 
                new List<RadioButton> {r0, r3, r4, r8, r10, r13, r16, r21, r24 };
            List<TabItem> tabItems = new List<TabItem>(tabControl1.Items.Cast<TabItem>());
            for (int i = 0; i < answerButtons.Count; i++)
            {
                if (answerButtons[i].IsChecked == true)
                {
                    int v = sum++;
                    tabItems[i].Background = Brushes.MediumSpringGreen;
                }
                else
                {
                    mistake++;
                    tabItems[i].Background = Brushes.Salmon;
                }
            }
            string[] numbers = Enumerable.Range(0, 10).Select(x => x.ToString()).ToArray(); 
            minus.Content = numbers[Math.Min(mistake, numbers.Length - 1)];
            plus.Content = numbers[Math.Min(sum, numbers.Length - 1)];
            plus.Foreground = Brushes.MediumSpringGreen;
            minus.Foreground = Brushes.Salmon;
            string fam = textBox1.Text.Trim();
            string fam1 = textBox2.Text.Trim();
            name.Content = fam;
            group.Content = fam1;
        }
    }
}